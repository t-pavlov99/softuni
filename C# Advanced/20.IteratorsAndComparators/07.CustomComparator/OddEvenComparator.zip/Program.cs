﻿namespace _07.CustomComparator;

internal class Program
{
    static void Main(string[] args)
    {
        int[] ints = Console.ReadLine().Split().Select(int.Parse).ToArray();
        Array.Sort(ints, new OddEvenComparator());
        Console.WriteLine(string.Join(" ", ints));
    }
}
