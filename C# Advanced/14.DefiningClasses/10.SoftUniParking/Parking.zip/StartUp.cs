﻿using System;

namespace SoftUniParking
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
        }
    }
}
