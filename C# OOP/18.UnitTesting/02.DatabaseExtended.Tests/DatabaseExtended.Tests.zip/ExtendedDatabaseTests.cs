namespace DatabaseExtended.Tests
{
    using ExtendedDatabase;
    using NUnit.Framework;
    using System;
    using System.Data.Common;
    using System.Reflection;

    [TestFixture]
    public class ExtendedDatabaseTests
    {
        private Person person1 = new Person(1, "Ivan");
        private Person person2 = new Person(2, "Maria");
        private Database db;

        [SetUp]
        public void SetUp()
        {
            db = new Database(person1, person2);
        }

        [Test]
        public void TestAddDuplicateUsername()
        {
            Assert.Throws<InvalidOperationException>(()  => db.Add(new Person(3, "Ivan")));
        }

        [Test]
        public void TestAddDuplicateID()
        {
            Assert.Throws<InvalidOperationException>(() => db.Add(new Person(1, "Gosho")));
        }

        [Test]
        public void TestRemovalWhenNonEmpty()
        {
            db.Remove();
            Assert.That(db.Count, Is.EqualTo(1));
        }

        [Test]
        public void TestRemovalWhenEmpty()
        {
            db.Remove();
            db.Remove();
            Assert.Throws<InvalidOperationException>( () => db.Remove());
        }

        [Test]
        public void TestFindWithNullUsername()
        {
            Assert.Throws<ArgumentNullException>(()=> db.FindByUsername(null));
        }

        [Test]
        public void TestFindWithMissingUsername()
        {
            Assert.Throws<InvalidOperationException>(() => db.FindByUsername("Gosho"));
        }

        [Test]
        public void TestCaseSensitivityOfFind()
        {
            Assert.Throws<InvalidOperationException>(() => db.FindByUsername("ivan"));
        }

        [Test]
        public void TestFindWithNegativeID()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => db.FindById(-1));
        }

        [Test]
        public void TestFindWithMissingID()
        {
            Assert.Throws<InvalidOperationException>(() => db.FindById(3));
        }

        [Test]
        public void TestAdditionWhenSpaceIsNotAvailable()
        {
            for (int i = 0; i < 14; i++)
                db.Add(new Person(i+5, $"{i}"));
            Assert.Throws<InvalidOperationException>(() =>
            {
                db.Add(new Person(20, "20"));
            }, "Array's capacity must be exactly 16 integers!");

        }

        [Test]
        public void TestCount()
        {
            for (int i = 1; i < 10; i++)
            {
                db.Add(new Person(i+2, $"{i}"));
                Assert.That(db.Count == i + 2);
            }


        }

        [Test]
        public void TestFindByIDWorks()
        {
            Assert.AreEqual(person1, db.FindById(1));
        }

        [Test]
        public void TestFindByNameWorks()
        {
            Assert.AreEqual(person2, db.FindByUsername("Maria"));
        }



    }
}