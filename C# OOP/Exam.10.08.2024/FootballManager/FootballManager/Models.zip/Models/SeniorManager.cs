﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FootballManager.Models
{
    internal class SeniorManager : Manager
    {
        public SeniorManager(string name) : base(name, 30) { }
        
    }
}
